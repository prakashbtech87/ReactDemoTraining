import { useEffect,useState } from "react";

export default function FunctionChild(props){
    const[upperCaseName,setUpperCaseName] = useState(props.name.toUpperCase());



useEffect(()=>{

    console.log("Funcution Chuld Component useEffect executed");
    setUpperCaseName(props.name.toUpperCase());
},[props])



    return(
        <div className="child=box">
            <p> Name from Parent : { props.name} </p>
            <p>  Name in CAPITAL (Child) : { upperCaseName}  </p>

        </div>
    );
}